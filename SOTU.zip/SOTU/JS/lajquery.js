

$(document).ready(function(){
   // alert("this is jquery");
    $("#service").click(function(){
        
       
       
    });

    $("#testimony").click(function(){
        $("#page").css({"background":"#ffdd43", "transition":"2s, ease-in-out, 2000ms"})
       
    });

    $("#contact").click(function(){
        $("#page").css({"background":"#8538e9", "transition":"2s, ease-in-out, 2000ms"})
       
    });

    $("#gallery").click(function(){
        $("#page").css({"background":"#3b89ff", "transition":"2s, ease-in-out, 2000ms"})
        
    });

});

$(document).ready(function(){
    $(".fa-list").click(function(){
        $("#navWrap").slideToggle("slow");
    });
});



   
