//alert('test js');

new Vue({
    el: '#menu1',
    data: {
        home: 'index.html',
        services: 'index.html',
        works: 'index.html',
        contact: 'index.html',
        gallery: 'index.html'
    }

});

