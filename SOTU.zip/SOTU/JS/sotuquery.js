$(document).ready(function(){
    $(".fa-bars").click(function(){
        $(".navWrap").animate({width:"toggle"});
    });
});